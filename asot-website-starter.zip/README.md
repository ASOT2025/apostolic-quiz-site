# Apostolic School of Theology — Website & Quizzes

This repository hosts static HTML quizzes and pages for the Apostolic School of Theology (ASOT).  
It is designed to work with **GitHub Pages** so you can link quizzes from Skool.com or anywhere else.

---

## 📁 Repository Structure

```text
.
├─ .gitattributes
├─ .nojekyll
├─ .github/
│  └─ workflows/
│     └─ pages.yml           # GitHub Pages workflow (deploys from the `main` branch)
├─ README.md
├─ index.html                # Landing page with links to sample content
├─ 404.html                  # Optional not-found page
├─ assets/
│  └─ styles.css             # Global styles
└─ quizzes/
   └─ intro-apostolic-theory-01.html  # Sample quiz page
```

> **Note**: `.nojekyll` disables Jekyll processing so your `assets/` and other folders serve as-is.

---

## 🚀 One-time setup (GitHub Pages)

1. Create a new repository on GitHub (e.g., `ASOT-Website`).
2. Upload everything in this ZIP (keep the structure exactly the same).
3. Go to **Settings → Pages**:
   - **Build and deployment** → *Source*: **GitHub Actions** (recommended).
   - The included workflow `.github/workflows/pages.yml` will build and deploy automatically when you push/commit.
4. After the Action completes, your site will be live at:
   - `https://<your-username>.github.io/ASOT-Website/`

If you prefer the older method (without Actions), you can set **Source** to *Deploy from a branch* → `main` / **root** and delete the `pages.yml` file.

---

## 🔗 Linking from Skool.com

- Use the full URL to the quiz page, e.g.  
  `https://<your-username>.github.io/ASOT-Website/quizzes/intro-apostolic-theory-01.html`

---

## ✍️ Adding more quizzes

1. Duplicate the sample file in `quizzes/` and rename it, e.g. `doctrines-of-baptisms-01.html`.
2. Edit the questions inside the file.
3. Add a link to your new quiz in `index.html` (or create a dedicated listing page).

### Simple grading/export ideas for static pages
- Include an answer key section that can be revealed (client-side) for self-check.
- Add a "Print to PDF" button for students to save/submit.
- If you need server-side collection, use a form backend (e.g., Google Forms) and just link to it.
  GitHub Pages is static (no servers or databases).

---

## 🧩 Troubleshooting

- **I only see code, not the website**: Make sure you’re visiting the **Pages URL** (see above), not `github.com/.../blob/main/...`.
- **CSS not loading**: Check the `<link rel="stylesheet" href="assets/styles.css">` path and case-sensitivity.
- **404 on quizzes**: Confirm the quiz file is in `quizzes/` and the filename in the link matches exactly.

---

## ©️ License

You can keep this repo private or make it public. Add a LICENSE if desired.
